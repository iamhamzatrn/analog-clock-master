module.exports = require('./vue-analog-clock-range.vue');
